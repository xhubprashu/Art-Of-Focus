import React, { useState, useEffect } from 'react';
import { Reminder } from '../types';
import useLocalStorage from '../hooks/useLocalStorage';

const ReminderList: React.FC = () => {
  const [reminders, setReminders] = useLocalStorage<Reminder[]>('reminders', []);
  const [text, setText] = useState('');
  const [time, setTime] = useState('');

  useEffect(() => {
    if ("Notification" in window && Notification.permission !== "granted") {
      Notification.requestPermission();
    }
  }, []);

  useEffect(() => {
    const checkReminders = () => {
      const now = new Date();
      const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;

      reminders.forEach(reminder => {
        if (reminder.active && reminder.time === currentTime) {
          if (Notification.permission === "granted") {
            new Notification("REMINDER", { body: reminder.text });
          }
        }
      });
    };
    const interval = setInterval(checkReminders, 60000);
    return () => clearInterval(interval);
  }, [reminders]);

  const addReminder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text || !time) return;
    setReminders([...reminders, {
      id: Date.now().toString(), text, time, active: true,
    }]);
    setText('');
    setTime('');
  };

  const deleteReminder = (id: string) => {
    setReminders(reminders.filter(r => r.id !== id));
  };

  return (
    <div className="bg-white p-6 border-4 border-black min-h-[300px] relative shadow-[8px_8px_0px_#1a2489]">
         <div className="flex items-center gap-4 mb-6 border-b-4 border-black pb-4">
            <div className="h-10 w-10 bg-m-red flex items-center justify-center text-white font-marker text-2xl border-2 border-black shadow-[2px_2px_0px_#000]">2</div>
            <h2 className="text-3xl font-serif text-black uppercase tracking-tighter font-bold">Signals</h2>
        </div>

        <form onSubmit={addReminder} className="mb-8 p-4 border-4 border-black bg-gray-50">
            <div className="flex flex-col gap-4">
                <input
                    type="text"
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                    placeholder="Signal message..."
                    className="bg-transparent text-black placeholder-gray-500 border-b-2 border-black focus:border-m-red focus:outline-none py-1 font-mono text-sm font-bold"
                />
                <div className="flex gap-4">
                    <input
                        type="time"
                        value={time}
                        onChange={(e) => setTime(e.target.value)}
                        className="bg-white text-black border-2 border-black px-2 py-1 font-mono text-sm focus:border-m-red focus:outline-none"
                    />
                    <button type="submit" className="bg-black text-white font-bold uppercase text-xs px-4 border-2 border-transparent hover:bg-m-light hover:border-black hover:text-black transition-colors shadow-[2px_2px_0px_#888]">
                        Set Signal
                    </button>
                </div>
            </div>
        </form>

        <div className="space-y-2">
            {reminders.map(r => (
                <div key={r.id} className="flex justify-between items-center bg-white p-3 border-4 border-black border-l-[12px] border-l-m-light group hover:translate-x-1 transition-transform">
                    <div>
                        <div className="text-m-dark font-mono text-xs font-black">{r.time}</div>
                        <div className="text-black font-bold">{r.text}</div>
                    </div>
                    <button
                        onClick={() => deleteReminder(r.id)}
                        className="text-gray-400 hover:text-m-red font-marker text-2xl font-bold"
                    >
                        ×
                    </button>
                </div>
            ))}
        </div>
    </div>
  );
};

export default ReminderList;