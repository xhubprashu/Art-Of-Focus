import React, { useState } from 'react';
import { Task } from '../types';
import useLocalStorage from '../hooks/useLocalStorage';

const TaskList: React.FC = () => {
  const [tasks, setTasks] = useLocalStorage<Task[]>('tasks', []);
  const [newTaskText, setNewTaskText] = useState('');

  const addTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskText.trim()) return;

    const newTask: Task = {
      id: Date.now().toString(),
      text: newTaskText,
      completed: false,
      createdAt: Date.now(),
    };

    setTasks([...tasks, newTask]);
    setNewTaskText('');
  };

  const toggleTask = (id: string) => {
    setTasks(tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  };

  const deleteTask = (id: string) => {
    setTasks(tasks.filter(t => t.id !== id));
  };

  return (
    <div className="bg-white text-black p-6 border-4 border-black min-h-[400px] shadow-[8px_8px_0px_#33b1e3] relative z-10">
        {/* Title */}
        <div className="flex items-center gap-4 mb-6 border-b-4 border-black pb-4">
            <div className="h-10 w-10 bg-m-dark flex items-center justify-center text-white font-marker text-2xl border-2 border-black shadow-[2px_2px_0px_#000]">1</div>
            <h2 className="text-3xl font-serif text-black uppercase tracking-tighter font-bold">Manifesto</h2>
        </div>

        {/* Input */}
        <form onSubmit={addTask} className="relative mb-8 group">
            <input
                type="text"
                value={newTaskText}
                onChange={(e) => setNewTaskText(e.target.value)}
                placeholder="What must be done?"
                className="w-full bg-gray-50 border-4 border-black py-3 px-4 text-xl font-bold placeholder-gray-400 focus:outline-none focus:border-m-red transition-colors font-sans"
            />
            <button 
                type="submit"
                className="absolute right-2 top-2 bottom-2 px-4 bg-m-red text-white hover:bg-black transition-colors font-bold uppercase text-sm tracking-widest border-2 border-black"
            >
                Add
            </button>
        </form>

        {/* List */}
        <div className="space-y-3">
            {tasks.length === 0 && (
                <div className="border-4 border-dashed border-gray-300 p-8 text-center text-gray-400 font-mono text-sm font-bold">
                    CANVAS IS EMPTY.
                </div>
            )}
            {tasks.map(task => (
                <div 
                    key={task.id}
                    className="flex items-start group cursor-pointer"
                    onClick={() => toggleTask(task.id)}
                >
                    {/* Custom Checkbox - Light Blue Accent */}
                    <div className={`mt-1 w-6 h-6 border-2 border-black mr-4 flex items-center justify-center transition-all ${task.completed ? 'bg-m-light' : 'bg-white hover:border-m-light'}`}>
                        {task.completed && <div className="text-black font-marker text-xl leading-none">✓</div>}
                    </div>
                    
                    <div className="flex-1 border-b-2 border-gray-100 pb-2 relative">
                        <span className={`text-lg font-bold transition-all ${task.completed ? 'text-gray-400 line-through decoration-m-red decoration-4' : 'text-black'}`}>
                            {task.text}
                        </span>
                         {/* Delete Button (Visible on Hover) */}
                         <button
                            onClick={(e) => { e.stopPropagation(); deleteTask(task.id); }}
                            className="absolute right-0 top-0 text-m-red opacity-0 group-hover:opacity-100 font-black hover:scale-125 transition-all text-xl"
                        >
                            ×
                        </button>
                    </div>
                </div>
            ))}
        </div>
    </div>
  );
};

export default TaskList;