import React, { useState, useEffect, useRef } from 'react';
import { TimerMode, WORK_TIME, BREAK_TIME } from '../types';

const PomodoroTimer: React.FC = () => {
  const [mode, setMode] = useState<TimerMode>(TimerMode.WORK);
  const [timeLeft, setTimeLeft] = useState(WORK_TIME);
  const [isActive, setIsActive] = useState(false);
  const intervalRef = useRef<number | null>(null);

  const totalTime = mode === TimerMode.WORK ? WORK_TIME : BREAK_TIME;
  const progress = ((totalTime - timeLeft) / totalTime) * 100;

  const notifyComplete = () => {
    if ("Notification" in window && Notification.permission === "granted") {
        new Notification("Session Ended", {
            body: mode === TimerMode.WORK ? "Take a break." : "Get back to work.",
            icon: "/icon.png"
        });
    }
  };

  const toggleTimer = () => {
    if (isActive) {
      if (intervalRef.current) clearInterval(intervalRef.current);
      setIsActive(false);
    } else {
      setIsActive(true);
    }
  };

  const resetTimer = () => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    setIsActive(false);
    setTimeLeft(mode === TimerMode.WORK ? WORK_TIME : BREAK_TIME);
  };

  const switchMode = (newMode: TimerMode) => {
    setMode(newMode);
    setIsActive(false);
    if (intervalRef.current) clearInterval(intervalRef.current);
    setTimeLeft(newMode === TimerMode.WORK ? WORK_TIME : BREAK_TIME);
  };

  useEffect(() => {
    if (isActive && timeLeft > 0) {
      intervalRef.current = window.setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      if (intervalRef.current) clearInterval(intervalRef.current);
      setIsActive(false);
      notifyComplete();
    }

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [isActive, timeLeft, mode]);

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60).toString().padStart(2, '0');
    const s = (seconds % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  return (
    <div className="bg-white border-4 border-black p-8 relative overflow-hidden group shadow-[8px_8px_0px_#e31d2b]">
        {/* Artistic corner accent */}
        <div className="absolute top-0 left-0 w-0 h-0 border-t-[60px] border-l-[60px] border-t-m-dark border-l-transparent z-10"></div>
        
        <div className="flex flex-col items-center relative z-20">
            <div className="flex justify-between w-full items-end mb-8 border-b-4 border-black pb-2">
                <h2 className="text-black font-serif text-3xl font-bold">Session</h2>
                <span className="text-m-red font-mono text-sm tracking-wider uppercase font-bold">{mode}</span>
            </div>

            {/* Timer Visual */}
            <div className="relative w-64 h-64 flex items-center justify-center mb-10">
                {/* Outer Ring */}
                <div className="absolute inset-0 border-4 border-gray-200 rounded-full rough-border"></div>
                
                {/* SVG Progress - M-Light Cyan */}
                <svg className="absolute w-full h-full transform -rotate-90 filter drop-shadow-[0_0_5px_rgba(51,177,227,0.5)]">
                    <circle
                        cx="128"
                        cy="128"
                        r="115"
                        stroke="#33b1e3"
                        strokeWidth="12"
                        fill="transparent"
                        strokeDasharray={2 * Math.PI * 115}
                        strokeDashoffset={2 * Math.PI * 115 * (1 - progress / 100)}
                        strokeLinecap="butt"
                        className="transition-all duration-1000 ease-linear ink-bleed"
                    />
                </svg>

                <div className="text-center z-10">
                    <div className="text-7xl font-sans font-black text-black tracking-tighter drop-shadow-sm">
                        {formatTime(timeLeft)}
                    </div>
                </div>
            </div>

            {/* Controls */}
            <div className="grid grid-cols-2 gap-4 w-full">
                <button
                    onClick={toggleTimer}
                    className={`
                        px-6 py-4 font-bold text-lg uppercase tracking-wider transition-all
                        border-4 border-black shadow-[4px_4px_0px_#000]
                        ${isActive 
                            ? 'bg-white text-black hover:bg-black hover:text-white' 
                            : 'bg-m-dark text-white hover:bg-black hover:text-white'
                        }
                    `}
                >
                    {isActive ? 'Pause' : 'Start'}
                </button>
                <button
                    onClick={resetTimer}
                    className="px-6 py-4 font-bold text-lg uppercase tracking-wider transition-all border-4 border-black bg-white text-black shadow-[4px_4px_0px_#000] hover:bg-gray-100"
                >
                    Reset
                </button>
            </div>

            {/* Mode Switcher */}
            <div className="flex gap-4 mt-8 w-full">
                <button
                    onClick={() => switchMode(TimerMode.WORK)}
                    className={`flex-1 py-2 text-sm font-mono border-b-4 transition-colors font-bold ${mode === TimerMode.WORK ? 'border-m-red text-black' : 'border-transparent text-gray-400 hover:text-black'}`}
                >
                    FOCUS
                </button>
                <button
                    onClick={() => switchMode(TimerMode.BREAK)}
                    className={`flex-1 py-2 text-sm font-mono border-b-4 transition-colors font-bold ${mode === TimerMode.BREAK ? 'border-m-light text-black' : 'border-transparent text-gray-400 hover:text-black'}`}
                >
                    REST
                </button>
            </div>
        </div>
    </div>
  );
};

export default PomodoroTimer;