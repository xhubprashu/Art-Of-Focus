import React, { useEffect, useState } from 'react';

const StencilDigit = ({ value }: { value: string }) => {
  return (
    <div className="relative w-12 h-16 sm:w-20 sm:h-24 flex items-center justify-center">
      {/* Background Stroke */}
      <div className="absolute inset-0 bg-white border-2 border-black transform rotate-1 rough-border shadow-[4px_4px_0px_#1a2489]"></div>
      
      {/* Number */}
      <span className="relative font-marker text-4xl sm:text-6xl text-black z-10">
        {value}
      </span>
    </div>
  );
};

const FlipClock: React.FC = () => {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (date: Date) => {
    const h = date.getHours().toString().padStart(2, '0');
    const m = date.getMinutes().toString().padStart(2, '0');
    const s = date.getSeconds().toString().padStart(2, '0');
    return { h, m, s };
  };

  const { h, m, s } = formatTime(time);

  return (
    <div className="flex items-center gap-2 sm:gap-4 p-4">
        <div className="flex gap-1 sm:gap-2">
            <StencilDigit value={h[0]} />
            <StencilDigit value={h[1]} />
        </div>
        
        <div className="text-m-red text-4xl font-marker animate-pulse relative top-[-5px] drop-shadow-[2px_2px_0px_#000]">:</div>
        
        <div className="flex gap-1 sm:gap-2">
            <StencilDigit value={m[0]} />
            <StencilDigit value={m[1]} />
        </div>
        
        <div className="hidden sm:block text-m-red text-4xl font-marker animate-pulse relative top-[-5px] drop-shadow-[2px_2px_0px_#000]">:</div>
        
        <div className="hidden sm:flex gap-1 sm:gap-2">
            <StencilDigit value={s[0]} />
            <StencilDigit value={s[1]} />
        </div>
    </div>
  );
};

export default FlipClock;